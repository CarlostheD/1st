﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInternet
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnEnterInternet = New System.Windows.Forms.Button()
        Me.mnuInternet = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblAverage = New System.Windows.Forms.Label()
        Me.lstInternetSpeed = New System.Windows.Forms.ListBox()
        Me.mnuInternet.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Tahoma", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(234, 22)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(745, 63)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Internet Speed Test Survey"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnEnterInternet
        '
        Me.btnEnterInternet.BackColor = System.Drawing.Color.DarkKhaki
        Me.btnEnterInternet.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnterInternet.Location = New System.Drawing.Point(433, 147)
        Me.btnEnterInternet.Name = "btnEnterInternet"
        Me.btnEnterInternet.Size = New System.Drawing.Size(347, 59)
        Me.btnEnterInternet.TabIndex = 1
        Me.btnEnterInternet.Text = "Enter Internet Speed"
        Me.btnEnterInternet.UseVisualStyleBackColor = False
        '
        'mnuInternet
        '
        Me.mnuInternet.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.mnuInternet.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.mnuInternet.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.mnuInternet.Location = New System.Drawing.Point(0, 0)
        Me.mnuInternet.Name = "mnuInternet"
        Me.mnuInternet.Size = New System.Drawing.Size(979, 33)
        Me.mnuInternet.TabIndex = 2
        Me.mnuInternet.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(54, 29)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(270, 34)
        Me.ClearToolStripMenuItem.Text = "&Clear"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(270, 34)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'lblAverage
        '
        Me.lblAverage.AutoSize = True
        Me.lblAverage.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAverage.Location = New System.Drawing.Point(336, 537)
        Me.lblAverage.Name = "lblAverage"
        Me.lblAverage.Size = New System.Drawing.Size(541, 34)
        Me.lblAverage.TabIndex = 3
        Me.lblAverage.Text = "Average Internet Speed: XX.XX Mbps"
        Me.lblAverage.Visible = False
        '
        'lstInternetSpeed
        '
        Me.lstInternetSpeed.Font = New System.Drawing.Font("Tahoma", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstInternetSpeed.FormattingEnabled = True
        Me.lstInternetSpeed.ItemHeight = 34
        Me.lstInternetSpeed.Location = New System.Drawing.Point(817, 147)
        Me.lstInternetSpeed.Name = "lstInternetSpeed"
        Me.lstInternetSpeed.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.lstInternetSpeed.Size = New System.Drawing.Size(120, 378)
        Me.lstInternetSpeed.TabIndex = 4
        '
        'frmInternet
        '
        Me.AcceptButton = Me.btnEnterInternet
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Internet_Speed_Test_Survey.My.Resources.Resources.speed
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(979, 638)
        Me.Controls.Add(Me.lstInternetSpeed)
        Me.Controls.Add(Me.lblAverage)
        Me.Controls.Add(Me.btnEnterInternet)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.mnuInternet)
        Me.MainMenuStrip = Me.mnuInternet
        Me.Name = "frmInternet"
        Me.Text = "Internet Speed Test Survey"
        Me.mnuInternet.ResumeLayout(False)
        Me.mnuInternet.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents btnEnterInternet As Button
    Friend WithEvents mnuInternet As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblAverage As Label
    Friend WithEvents lstInternetSpeed As ListBox
End Class
