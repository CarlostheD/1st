﻿' Program Name: Internet Speed Test Survey
' Author:       Carlos Davalos
' Date:         July 10, 2022
' Purpose:      The Internet Speed Test Survey enters the Internet speeds. It displays
'               each internet speed. After all the internet speeds have been entered, it
'               displays the average internet speed.

Option Strict On

Public Class frmInternet
    Private Sub btnEnterInternet_Click(sender As Object, e As EventArgs) Handles btnEnterInternet.Click
        ' The btnEnterInternet_Click event accepts and displays up to 10 internet speed values
        ' and then calculates and displays the average internet speed.

        'Declare and initialize variables
        Dim strInternetSpeed As String
        Dim decInternetSpeed As Decimal
        Dim decAverage As Decimal
        Dim decTotalInternetSpeed As Decimal = 0D
        Dim strInputMessage As String = "Enter the internet speed for #"
        Dim strInputHeading As String = "Internet speed"
        Dim strNormalMessage As String = "Enter the internet speed of #"
        Dim strNonnumericError As String = "Error - Enter a number for the internet speed #"
        Dim strNegativeError As String = "Error - enter a postive number for the internet speed #"

        ' Declare and initialize loop variables
        Dim strCancelClicked As String = ""
        Dim intMaxNumberOfEntries As Integer = 10
        Dim intNumberOfEntries As Integer = 1

        ' This loop allows the user to enter 10 different internet speeds.
        ' The loop terminates when the user has entered 8 internet speed values or the user
        ' clicks the cancel button or the Close button in the InputBox
        strInternetSpeed = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")

        Do Until intNumberOfEntries > intMaxNumberOfEntries Or strInternetSpeed = strCancelClicked
            If IsNumeric(strInternetSpeed) Then
                decInternetSpeed = Convert.ToDecimal(strInternetSpeed)
                If decInternetSpeed > 0 Then
                    lstInternetSpeed.Items.Add(decInternetSpeed)
                    decTotalInternetSpeed += decInternetSpeed
                    intNumberOfEntries += 1
                    strInputMessage = strNormalMessage
                Else
                    strInputMessage = strNegativeError
                End If
            Else
                strInputMessage = strNonnumericError
            End If
            If intNumberOfEntries <= intMaxNumberOfEntries Then
                strInternetSpeed = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
            End If
        Loop
        ' Calculates and displays average Internet Speed
        If intNumberOfEntries > 1 Then
            lblAverage.Visible = True
            decAverage = decTotalInternetSpeed / (intNumberOfEntries - 1)
            lblAverage.Text = "Average Internet Speed is" &
                decAverage.ToString("F1") & "mbps"
        Else
            MsgBox("No internet speed entered")
        End If

        ' Disables the Enter Internet Speed
        btnEnterInternet.Enabled = False
    End Sub

    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        ' The mnuClear click event clears the Listbox object and hides
        ' the average internet speed label. It also enables the Enter Internet Speed button.

        lstInternetSpeed.Items.Clear()
        lblAverage.Visible = False
        btnEnterInternet.Enabled = True
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        ' The mnuExit click event closes the window and exits the application

        Close()

    End Sub
End Class
