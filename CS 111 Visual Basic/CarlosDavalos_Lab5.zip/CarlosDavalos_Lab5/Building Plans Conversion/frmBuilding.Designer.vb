﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBuilding
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.GrpConversion = New System.Windows.Forms.GroupBox()
        Me.radMetric = New System.Windows.Forms.RadioButton()
        Me.radImperial = New System.Windows.Forms.RadioButton()
        Me.lblAmounttoConvert = New System.Windows.Forms.Label()
        Me.lblConversionResult = New System.Windows.Forms.Label()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GrpConversion.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Goudy Old Style", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.Color.SaddleBrown
        Me.lblHeading.Location = New System.Drawing.Point(33, 24)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(371, 37)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Building Plans Conversion"
        '
        'txtAmount
        '
        Me.txtAmount.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAmount.ForeColor = System.Drawing.Color.SaddleBrown
        Me.txtAmount.Location = New System.Drawing.Point(319, 82)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(100, 41)
        Me.txtAmount.TabIndex = 1
        '
        'GrpConversion
        '
        Me.GrpConversion.Controls.Add(Me.radMetric)
        Me.GrpConversion.Controls.Add(Me.radImperial)
        Me.GrpConversion.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GrpConversion.ForeColor = System.Drawing.Color.SaddleBrown
        Me.GrpConversion.Location = New System.Drawing.Point(108, 156)
        Me.GrpConversion.Name = "GrpConversion"
        Me.GrpConversion.Size = New System.Drawing.Size(282, 124)
        Me.GrpConversion.TabIndex = 2
        Me.GrpConversion.TabStop = False
        Me.GrpConversion.Text = "Conversion Type"
        '
        'radMetric
        '
        Me.radMetric.AutoSize = True
        Me.radMetric.Location = New System.Drawing.Point(20, 82)
        Me.radMetric.Name = "radMetric"
        Me.radMetric.Size = New System.Drawing.Size(241, 36)
        Me.radMetric.TabIndex = 1
        Me.radMetric.TabStop = True
        Me.radMetric.Text = "Metric to Imperial"
        Me.radMetric.UseVisualStyleBackColor = True
        '
        'radImperial
        '
        Me.radImperial.AutoSize = True
        Me.radImperial.Location = New System.Drawing.Point(20, 40)
        Me.radImperial.Name = "radImperial"
        Me.radImperial.Size = New System.Drawing.Size(241, 36)
        Me.radImperial.TabIndex = 0
        Me.radImperial.TabStop = True
        Me.radImperial.Text = "Imperial to Metric"
        Me.radImperial.UseVisualStyleBackColor = True
        '
        'lblAmounttoConvert
        '
        Me.lblAmounttoConvert.AutoSize = True
        Me.lblAmounttoConvert.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAmounttoConvert.ForeColor = System.Drawing.Color.SaddleBrown
        Me.lblAmounttoConvert.Location = New System.Drawing.Point(75, 85)
        Me.lblAmounttoConvert.Name = "lblAmounttoConvert"
        Me.lblAmounttoConvert.Size = New System.Drawing.Size(235, 32)
        Me.lblAmounttoConvert.TabIndex = 3
        Me.lblAmounttoConvert.Text = "Amount to Convert"
        '
        'lblConversionResult
        '
        Me.lblConversionResult.AutoSize = True
        Me.lblConversionResult.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConversionResult.ForeColor = System.Drawing.Color.SaddleBrown
        Me.lblConversionResult.Location = New System.Drawing.Point(51, 318)
        Me.lblConversionResult.Name = "lblConversionResult"
        Me.lblConversionResult.Size = New System.Drawing.Size(226, 32)
        Me.lblConversionResult.TabIndex = 4
        Me.lblConversionResult.Text = "Conversion Result:"
        '
        'lblResult
        '
        Me.lblResult.AutoSize = True
        Me.lblResult.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResult.ForeColor = System.Drawing.Color.SaddleBrown
        Me.lblResult.Location = New System.Drawing.Point(283, 318)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(184, 32)
        Me.lblResult.TabIndex = 5
        Me.lblResult.Text = "XXXX.XXXXX"
        '
        'btnConvert
        '
        Me.btnConvert.BackColor = System.Drawing.Color.White
        Me.btnConvert.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnConvert.ForeColor = System.Drawing.Color.SaddleBrown
        Me.btnConvert.Location = New System.Drawing.Point(81, 387)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(132, 40)
        Me.btnConvert.TabIndex = 6
        Me.btnConvert.Text = "Convert"
        Me.btnConvert.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.White
        Me.btnClear.Font = New System.Drawing.Font("Goudy Old Style", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.SaddleBrown
        Me.btnClear.Location = New System.Drawing.Point(296, 387)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(132, 40)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Building_Plans_Conversion.My.Resources.Resources.Metric_imperial
        Me.PictureBox1.Location = New System.Drawing.Point(465, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(339, 449)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'frmBuilding
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.lblConversionResult)
        Me.Controls.Add(Me.lblAmounttoConvert)
        Me.Controls.Add(Me.GrpConversion)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.lblHeading)
        Me.ForeColor = System.Drawing.Color.SaddleBrown
        Me.Name = "frmBuilding"
        Me.Text = "Building Plans Conversion"
        Me.GrpConversion.ResumeLayout(False)
        Me.GrpConversion.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHeading As Label
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents GrpConversion As GroupBox
    Friend WithEvents radMetric As RadioButton
    Friend WithEvents radImperial As RadioButton
    Friend WithEvents lblAmounttoConvert As Label
    Friend WithEvents lblConversionResult As Label
    Friend WithEvents lblResult As Label
    Friend WithEvents btnConvert As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
