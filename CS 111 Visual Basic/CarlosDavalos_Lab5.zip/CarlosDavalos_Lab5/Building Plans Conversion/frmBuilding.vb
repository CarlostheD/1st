﻿' Program Name: Building Plans Conversion
' Author:       Carlos Davalos
' Date:         July 3, 2022
' Purpose:      This windows application computes the amount of either meters or inches based on the
'               number of inputted either meters or inches.  one inch = 0.0254 meters. One meter = 39.37008 inches

Option Strict On
Public Class frmBuilding

    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        ' The btnConvert event handler calculates the amount of desired measurement wanted to convert
        ' from imperial to metric or metric to imperial.

        'Declaration Selection
        Dim decAmount As Decimal
        Dim decResult As Decimal
        Dim decAmounttoConvert As Decimal
        Dim decMetric As Decimal = 39.37008D
        Dim decImperial As Decimal = 0.0254D

        'Did user enter a numeric value?
        If IsNumeric(txtAmount.Text) Then
            decAmount = Convert.ToDecimal(txtAmount.Text)
            ' Is Amount Entered greater than zero?
            If decAmount > 0 Then
                ' Determine conversion of amount
                If radMetric.Checked Then
                    decAmounttoConvert = decMetric
                ElseIf radImperial.Checked Then
                    decAmounttoConvert = decImperial
                End If
                ' Calculate and Display total converted amount
                decResult = decAmount * decAmounttoConvert
                lblResult.Text = decResult.ToString("G")
            Else
                ' Display error message if user entered a negative value
                MsgBox("You entered" & decAmount.ToString() & ". Enter a Positive Number", , "Input Error")
                txtAmount.Text = ""
                txtAmount.Focus()
            End If
        Else
            'Display error message if user entered a nonnumeric value
            MsgBox("Enter the Amount to be Converted", , "Input Error")
            txtAmount.Text = ""
            txtAmount.Focus()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ' This event handler is executed when the user clicks the Clear button. it
        ' clears the Amount in textbox and the cost of the Result Label, resets the radio
        ' buttons with Imperial to Metric selected, and sets the focus on the Amount Text box.
        txtAmount.Clear()
        lblResult.Text = ""
        radImperial.Checked = True
        radMetric.Checked = False
        txtAmount.Focus()

    End Sub

    Private Sub frmBuilding_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' This event handler is executed when the form is loaded at the start of
        ' the program. it Sets the focus on the Amount Text box and
        ' Clears the result label.

        txtAmount.Focus()
        lblResult.Text = ""

    End Sub
End Class
