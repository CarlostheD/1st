﻿Public Class frmBurgerSpecials
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblConfirmation.Click

    End Sub
End Class
